﻿
namespace lados
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblA = new System.Windows.Forms.Label();
            this.lblC = new System.Windows.Forms.Label();
            this.lblB = new System.Windows.Forms.Label();
            this.BtnExecuta = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.TxtValA = new System.Windows.Forms.TextBox();
            this.TxtValC = new System.Windows.Forms.TextBox();
            this.TxtValB = new System.Windows.Forms.TextBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Font = new System.Drawing.Font("Arial Narrow", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblA.Location = new System.Drawing.Point(47, 64);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(99, 33);
            this.lblA.TabIndex = 0;
            this.lblA.Text = "Valor A";
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Font = new System.Drawing.Font("Arial Narrow", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblC.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblC.Location = new System.Drawing.Point(47, 222);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(99, 33);
            this.lblC.TabIndex = 1;
            this.lblC.Text = "Valor C";
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Font = new System.Drawing.Font("Arial Narrow", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblB.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblB.Location = new System.Drawing.Point(47, 142);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(99, 33);
            this.lblB.TabIndex = 2;
            this.lblB.Text = "Valor B";
            // 
            // BtnExecuta
            // 
            this.BtnExecuta.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExecuta.ForeColor = System.Drawing.Color.DarkCyan;
            this.BtnExecuta.Location = new System.Drawing.Point(53, 347);
            this.BtnExecuta.Name = "BtnExecuta";
            this.BtnExecuta.Size = new System.Drawing.Size(326, 37);
            this.BtnExecuta.TabIndex = 3;
            this.BtnExecuta.Text = "Executar";
            this.BtnExecuta.UseVisualStyleBackColor = true;
            this.BtnExecuta.Click += new System.EventHandler(this.btnExecuta_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.Color.DarkCyan;
            this.btnLimpar.Location = new System.Drawing.Point(602, 214);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(103, 52);
            this.btnLimpar.TabIndex = 5;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // TxtValA
            // 
            this.TxtValA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtValA.Location = new System.Drawing.Point(241, 69);
            this.TxtValA.Name = "TxtValA";
            this.TxtValA.Size = new System.Drawing.Size(138, 29);
            this.TxtValA.TabIndex = 6;
            // 
            // TxtValC
            // 
            this.TxtValC.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtValC.Location = new System.Drawing.Point(241, 222);
            this.TxtValC.Name = "TxtValC";
            this.TxtValC.Size = new System.Drawing.Size(138, 29);
            this.TxtValC.TabIndex = 7;
            // 
            // TxtValB
            // 
            this.TxtValB.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtValB.Location = new System.Drawing.Point(241, 142);
            this.TxtValB.Name = "TxtValB";
            this.TxtValB.Size = new System.Drawing.Size(138, 29);
            this.TxtValB.TabIndex = 8;
            // 
            // btnSair
            // 
            this.btnSair.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.Color.DarkCyan;
            this.btnSair.Location = new System.Drawing.Point(602, 64);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(103, 52);
            this.btnSair.TabIndex = 9;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.TxtValB);
            this.Controls.Add(this.TxtValC);
            this.Controls.Add(this.TxtValA);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.BtnExecuta);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.lblA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.Button BtnExecuta;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.TextBox TxtValA;
        private System.Windows.Forms.TextBox TxtValC;
        private System.Windows.Forms.TextBox TxtValB;
        private System.Windows.Forms.Button btnSair;
    }
}

