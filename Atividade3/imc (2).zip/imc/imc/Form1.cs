﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace imc
{
    public partial class Form1 : Form
    {
        Double numImc;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double imc;
            double altura;
            double peso; 

            if(Double.TryParse(txtAltura.Text, out altura) && Double.TryParse(txtPeso.Text, out peso))
            {
                if((altura <= 0) || (peso <= 0))
                {
                    MessageBox.Show("Valores devem ser maiores que zero");
                }
                else
                {
                    imc = peso / (Math.Pow(altura, 2));

                    imc = Math.Round(imc, 1);

                    txtImc.Text = imc.ToString("N1");

                    numImc = imc;

                }

                this.txtClassif_TextChanged(sender, e);
            }
        }

        private void txtClassif_TextChanged(object sender, EventArgs e)
        {
            if (numImc <= 18.5)
            {
                txtClassif.Text = ("Baixo Peso");
            }
            else if (numImc <= 24.9)
            {
                txtClassif.Text = ("Peso normal");
            }
            else if (numImc <= 29.9)
            {
                txtClassif.Text = ("Sobrepeso");
            }
            else if (numImc <= 34.9)
            {
                txtClassif.Text = ("Obesidade grau I");
            }
            else if(numImc <= 39.9)
            {
                txtClassif.Text = ("Obesidade grau II");
            }
            else if(numImc >= 40)
            {
                txtClassif.Text = ("Obesidade grau III");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtClassif.Clear();
            txtImc.Clear();
            txtPeso.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
