﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P_0030482111038
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            
            ltb.Items.Clear();

            int l = 8, c = 16;

            double[,] m = new double[l, c];
            double[] somaMes = new double[l];
            double somaTotal = 0;

            string aux = "";



            for (int i = 0; i < l; i++)
            {

                double soma = 0;

                ltb.Items.Add(" ___________________________________");
                ltb.Items.Add(" ");

                for (int j = 0; j < c; j++)
                {
                    aux = Interaction.InputBox(" Total da Semana \n[Semana]: " + (j + 1).ToString() + "\n[Mês]: " + (i + 1).ToString());

                    if (double.TryParse(aux, out m[i, j]))
                    {

                        m[i, j] = Convert.ToDouble(aux);
                        somaTotal = somaTotal + m[i, j];
                        soma = soma + m[i, j];

                        ltb.Items.Add(" Total do mês: " + (i + 1).ToString() + " Semana: " + (j + 1) + (" ") + (String.Format("{0:C8}", m[i, j])));

                    }
                    else
                    {
                        MessageBox.Show("Dados Inválidos");
                        j--;
                    }


                }

                somaMes[i] = soma;

                ltb.Items.Add(" ");
                ltb.Items.Add(" >> Total Mês:" + (String.Format("{0:C8}", somaMes[i])));
                ltb.Items.Add(" ");

            }

            ltb.Items.Add(" ___________________________________");
            ltb.Items.Add(" ");
            ltb.Items.Add(" Total Geral: " + (String.Format("{0:C8}", somaTotal)));
            ltb.Items.Add(" ___________________________________\n\n");
        }
    }
}
