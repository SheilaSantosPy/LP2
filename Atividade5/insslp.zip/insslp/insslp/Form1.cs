﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace insslp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnVerif_Click(object sender, EventArgs e)
        {
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double salarioLiquido = 0;
            double descontoInss = 0;
            double descontoIR = 0;

            if ((txtNome.Text == "") || (txtNome.Text.Length < 5))
                MessageBox.Show("Nome inválido");
            else if (double.TryParse(txtSalBruto.Text, out salarioBruto))
            {

                // Desconto INSS

                if (salarioBruto <= 0)
                {
                    MessageBox.Show("Salário inválido");
                }
                
                else if ( salarioBruto <= 800.47)
                {
                    txtAliqInss.Text = "7.65%";
                    descontoInss = 0.0765 * salarioBruto;
                }

                else if (salarioBruto <= 1050)
                {
                    txtAliqInss.Text = "8.65%";
                    descontoInss = 0.0865 * salarioBruto;
                }

                else if (salarioBruto <= 1400.77)
                {
                    txtAliqInss.Text = "9%";
                    descontoInss = 0.09 * salarioBruto;
                }

                else if(salarioBruto <= 2801.56)
                {
                    txtAliqInss.Text = "11%";
                    descontoInss = 0.11 * salarioBruto;
                }

                else
                {
                    txtAliqInss.Text = "11%";
                    descontoInss = 308.17;
                }

                txtDescInss.Text = descontoInss.ToString("N2");

                // Desconto IR

                if (salarioBruto <= 1257.12)
                {
                    descontoIR = 0;

                }

                else if (salarioBruto <= 2512.08)
                {
                    txtAliqIR.Text = "15%";
                    descontoIR = 0.15 * salarioBruto;
                }

                else
                {
                    txtAliqIR.Text = "27.5%";
                    descontoIR = 0.275 * salarioBruto;
                }

                txtDescIr.Text = descontoIR.ToString("N2");

                // Salário Família

                if (salarioBruto <= 435.52)
                {
                    salarioFamilia = 22.33 * Convert.ToDouble(cBoxDep.SelectedItem);
                    txtSalFam.Text = salarioFamilia.ToString("N2");
                }

                else if (salarioFamilia <= 654.61)
                {
                    salarioFamilia = 15.74 * Convert.ToDouble(cBoxDep.SelectedItem);
                    txtSalFam.Text = salarioFamilia.ToString("N2");
                }

                else
                {
                    salarioFamilia = 0;
                    txtSalFam.Text = salarioFamilia.ToString("N2");
                }

                // Salário Líquido 

                salarioLiquido = salarioBruto - descontoInss - descontoIR + salarioFamilia;
                txtSalLiq.Text = salarioLiquido.ToString("N2");

                // Mensagem no Label

                lblMsg.Visible = true;
                lblMsg.Text = " Os descontos do salário " + (rbtnFem.Checked ? " da Sra " : " do Sr ") + txtNome.Text + " que é " + (cboxCasado.Checked ? " casado (a) " : " solteiro (a) ") + " e que possui " + cBoxDep.SelectedItem + " dependentes" + ", é: " + salarioLiquido;

            }
      
            

        }
        private void txtNome_Validated(object sender, EventArgs e)
        {
            if ((txtNome.Text == "") || (txtNome.Text.Length < 5))
            {
                MessageBox.Show("Nome inválido");
                txtNome.Focus();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cBoxDep.SelectedIndex = 0;
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtSalBruto.Clear();
            txtAliqInss.Clear();
            txtAliqIR.Clear();
            txtSalFam.Clear();
            txtSalLiq.Clear();
            txtDescInss.Clear();
            txtDescIr.Clear();

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
