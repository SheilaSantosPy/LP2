﻿
namespace insslp
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFunc = new System.Windows.Forms.Label();
            this.lblDep = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalBruto = new System.Windows.Forms.TextBox();
            this.lblAliqInss = new System.Windows.Forms.Label();
            this.lblAliqIR = new System.Windows.Forms.Label();
            this.SalLiq = new System.Windows.Forms.Label();
            this.lblSalFam = new System.Windows.Forms.Label();
            this.txtAliqIR = new System.Windows.Forms.TextBox();
            this.txtAliqInss = new System.Windows.Forms.TextBox();
            this.txtSalFam = new System.Windows.Forms.TextBox();
            this.lblDescIr = new System.Windows.Forms.Label();
            this.lblDescInss = new System.Windows.Forms.Label();
            this.txtDescInss = new System.Windows.Forms.TextBox();
            this.txtDescIr = new System.Windows.Forms.TextBox();
            this.cBoxDep = new System.Windows.Forms.ComboBox();
            this.gBoxCasado = new System.Windows.Forms.GroupBox();
            this.cboxCasado = new System.Windows.Forms.CheckBox();
            this.gBoxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnMasc = new System.Windows.Forms.RadioButton();
            this.rbtnFem = new System.Windows.Forms.RadioButton();
            this.btnVerif = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.txtSalLiq = new System.Windows.Forms.TextBox();
            this.lblMsg = new System.Windows.Forms.Label();
            this.gBoxCasado.SuspendLayout();
            this.gBoxSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblFunc
            // 
            this.lblFunc.AutoSize = true;
            this.lblFunc.Font = new System.Drawing.Font("Arial Narrow", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblFunc.Location = new System.Drawing.Point(24, 8);
            this.lblFunc.Name = "lblFunc";
            this.lblFunc.Size = new System.Drawing.Size(168, 25);
            this.lblFunc.TabIndex = 0;
            this.lblFunc.Text = "Nome Funcionário";
            // 
            // lblDep
            // 
            this.lblDep.AutoSize = true;
            this.lblDep.Font = new System.Drawing.Font("Arial Narrow", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDep.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblDep.Location = new System.Drawing.Point(24, 91);
            this.lblDep.Name = "lblDep";
            this.lblDep.Size = new System.Drawing.Size(179, 25);
            this.lblDep.TabIndex = 4;
            this.lblDep.Text = "Número de Depente";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Font = new System.Drawing.Font("Arial Narrow", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalBruto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblSalBruto.Location = new System.Drawing.Point(24, 48);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(123, 25);
            this.lblSalBruto.TabIndex = 5;
            this.lblSalBruto.Text = "Salário Bruto";
            // 
            // txtNome
            // 
            this.txtNome.BackColor = System.Drawing.SystemColors.Info;
            this.txtNome.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtNome.Location = new System.Drawing.Point(274, 13);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(265, 20);
            this.txtNome.TabIndex = 6;
            this.txtNome.Validated += new System.EventHandler(this.txtNome_Validated);
            // 
            // txtSalBruto
            // 
            this.txtSalBruto.BackColor = System.Drawing.SystemColors.Info;
            this.txtSalBruto.Location = new System.Drawing.Point(274, 52);
            this.txtSalBruto.Name = "txtSalBruto";
            this.txtSalBruto.Size = new System.Drawing.Size(265, 20);
            this.txtSalBruto.TabIndex = 8;
            // 
            // lblAliqInss
            // 
            this.lblAliqInss.AutoSize = true;
            this.lblAliqInss.Font = new System.Drawing.Font("Arial Narrow", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliqInss.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblAliqInss.Location = new System.Drawing.Point(24, 214);
            this.lblAliqInss.Name = "lblAliqInss";
            this.lblAliqInss.Size = new System.Drawing.Size(127, 25);
            this.lblAliqInss.TabIndex = 9;
            this.lblAliqInss.Text = "Alíquota INSS";
            // 
            // lblAliqIR
            // 
            this.lblAliqIR.AutoSize = true;
            this.lblAliqIR.Font = new System.Drawing.Font("Arial Narrow", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliqIR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblAliqIR.Location = new System.Drawing.Point(24, 256);
            this.lblAliqIR.Name = "lblAliqIR";
            this.lblAliqIR.Size = new System.Drawing.Size(105, 25);
            this.lblAliqIR.TabIndex = 10;
            this.lblAliqIR.Text = "Alíquota IR";
            // 
            // SalLiq
            // 
            this.SalLiq.AutoSize = true;
            this.SalLiq.Font = new System.Drawing.Font("Arial Narrow", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalLiq.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SalLiq.Location = new System.Drawing.Point(24, 360);
            this.SalLiq.Name = "SalLiq";
            this.SalLiq.Size = new System.Drawing.Size(182, 31);
            this.SalLiq.TabIndex = 11;
            this.SalLiq.Text = "Salário Líquido ";
            // 
            // lblSalFam
            // 
            this.lblSalFam.AutoSize = true;
            this.lblSalFam.Font = new System.Drawing.Font("Arial Narrow", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalFam.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblSalFam.Location = new System.Drawing.Point(24, 299);
            this.lblSalFam.Name = "lblSalFam";
            this.lblSalFam.Size = new System.Drawing.Size(137, 25);
            this.lblSalFam.TabIndex = 12;
            this.lblSalFam.Text = "Salário Família";
            // 
            // txtAliqIR
            // 
            this.txtAliqIR.BackColor = System.Drawing.SystemColors.Info;
            this.txtAliqIR.Location = new System.Drawing.Point(274, 260);
            this.txtAliqIR.Name = "txtAliqIR";
            this.txtAliqIR.ReadOnly = true;
            this.txtAliqIR.Size = new System.Drawing.Size(265, 20);
            this.txtAliqIR.TabIndex = 13;
            // 
            // txtAliqInss
            // 
            this.txtAliqInss.BackColor = System.Drawing.SystemColors.Info;
            this.txtAliqInss.Location = new System.Drawing.Point(274, 218);
            this.txtAliqInss.Name = "txtAliqInss";
            this.txtAliqInss.ReadOnly = true;
            this.txtAliqInss.Size = new System.Drawing.Size(265, 20);
            this.txtAliqInss.TabIndex = 14;
            // 
            // txtSalFam
            // 
            this.txtSalFam.BackColor = System.Drawing.SystemColors.Info;
            this.txtSalFam.Location = new System.Drawing.Point(274, 303);
            this.txtSalFam.Name = "txtSalFam";
            this.txtSalFam.ReadOnly = true;
            this.txtSalFam.Size = new System.Drawing.Size(265, 20);
            this.txtSalFam.TabIndex = 15;
            // 
            // lblDescIr
            // 
            this.lblDescIr.AutoSize = true;
            this.lblDescIr.Font = new System.Drawing.Font("Arial Narrow", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescIr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblDescIr.Location = new System.Drawing.Point(652, 299);
            this.lblDescIr.Name = "lblDescIr";
            this.lblDescIr.Size = new System.Drawing.Size(115, 25);
            this.lblDescIr.TabIndex = 17;
            this.lblDescIr.Text = "Desconto IR";
            // 
            // lblDescInss
            // 
            this.lblDescInss.AutoSize = true;
            this.lblDescInss.Font = new System.Drawing.Font("Arial Narrow", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescInss.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblDescInss.Location = new System.Drawing.Point(652, 214);
            this.lblDescInss.Name = "lblDescInss";
            this.lblDescInss.Size = new System.Drawing.Size(137, 25);
            this.lblDescInss.TabIndex = 18;
            this.lblDescInss.Text = "Desconto INSS";
            // 
            // txtDescInss
            // 
            this.txtDescInss.BackColor = System.Drawing.SystemColors.Info;
            this.txtDescInss.Location = new System.Drawing.Point(625, 260);
            this.txtDescInss.Name = "txtDescInss";
            this.txtDescInss.ReadOnly = true;
            this.txtDescInss.Size = new System.Drawing.Size(265, 20);
            this.txtDescInss.TabIndex = 19;
            // 
            // txtDescIr
            // 
            this.txtDescIr.BackColor = System.Drawing.SystemColors.Info;
            this.txtDescIr.Location = new System.Drawing.Point(625, 345);
            this.txtDescIr.Name = "txtDescIr";
            this.txtDescIr.ReadOnly = true;
            this.txtDescIr.Size = new System.Drawing.Size(265, 20);
            this.txtDescIr.TabIndex = 20;
            // 
            // cBoxDep
            // 
            this.cBoxDep.BackColor = System.Drawing.SystemColors.Info;
            this.cBoxDep.FormattingEnabled = true;
            this.cBoxDep.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14"});
            this.cBoxDep.Location = new System.Drawing.Point(274, 95);
            this.cBoxDep.Name = "cBoxDep";
            this.cBoxDep.Size = new System.Drawing.Size(265, 22);
            this.cBoxDep.TabIndex = 24;
            // 
            // gBoxCasado
            // 
            this.gBoxCasado.Controls.Add(this.cboxCasado);
            this.gBoxCasado.Location = new System.Drawing.Point(30, 135);
            this.gBoxCasado.Name = "gBoxCasado";
            this.gBoxCasado.Size = new System.Drawing.Size(190, 64);
            this.gBoxCasado.TabIndex = 25;
            this.gBoxCasado.TabStop = false;
            // 
            // cboxCasado
            // 
            this.cboxCasado.AutoSize = true;
            this.cboxCasado.Checked = true;
            this.cboxCasado.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cboxCasado.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxCasado.Location = new System.Drawing.Point(40, 18);
            this.cboxCasado.Name = "cboxCasado";
            this.cboxCasado.Size = new System.Drawing.Size(95, 26);
            this.cboxCasado.TabIndex = 0;
            this.cboxCasado.Text = "Casado";
            this.cboxCasado.UseVisualStyleBackColor = true;
            // 
            // gBoxSexo
            // 
            this.gBoxSexo.Controls.Add(this.rbtnMasc);
            this.gBoxSexo.Controls.Add(this.rbtnFem);
            this.gBoxSexo.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gBoxSexo.Location = new System.Drawing.Point(274, 135);
            this.gBoxSexo.Name = "gBoxSexo";
            this.gBoxSexo.Size = new System.Drawing.Size(266, 64);
            this.gBoxSexo.TabIndex = 26;
            this.gBoxSexo.TabStop = false;
            this.gBoxSexo.Text = "Sexo";
            // 
            // rbtnMasc
            // 
            this.rbtnMasc.AutoSize = true;
            this.rbtnMasc.Location = new System.Drawing.Point(145, 20);
            this.rbtnMasc.Name = "rbtnMasc";
            this.rbtnMasc.Size = new System.Drawing.Size(96, 22);
            this.rbtnMasc.TabIndex = 1;
            this.rbtnMasc.Text = "Masculino";
            this.rbtnMasc.UseVisualStyleBackColor = true;
            // 
            // rbtnFem
            // 
            this.rbtnFem.AutoSize = true;
            this.rbtnFem.Checked = true;
            this.rbtnFem.Location = new System.Drawing.Point(15, 22);
            this.rbtnFem.Name = "rbtnFem";
            this.rbtnFem.Size = new System.Drawing.Size(91, 22);
            this.rbtnFem.TabIndex = 0;
            this.rbtnFem.TabStop = true;
            this.rbtnFem.Text = "Feminino";
            this.rbtnFem.UseVisualStyleBackColor = true;
            // 
            // btnVerif
            // 
            this.btnVerif.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnVerif.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerif.ForeColor = System.Drawing.Color.Snow;
            this.btnVerif.Location = new System.Drawing.Point(657, 22);
            this.btnVerif.Name = "btnVerif";
            this.btnVerif.Size = new System.Drawing.Size(190, 80);
            this.btnVerif.TabIndex = 27;
            this.btnVerif.Text = "Verificar descontos";
            this.btnVerif.UseVisualStyleBackColor = false;
            this.btnVerif.Click += new System.EventHandler(this.btnVerif_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.Lavender;
            this.btnLimpar.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnLimpar.Location = new System.Drawing.Point(274, 434);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(265, 38);
            this.btnLimpar.TabIndex = 28;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.Lavender;
            this.btnSair.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.btnSair.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSair.Location = new System.Drawing.Point(625, 434);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(265, 38);
            this.btnSair.TabIndex = 29;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.BackColor = System.Drawing.SystemColors.Info;
            this.txtSalLiq.Font = new System.Drawing.Font("Arial", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalLiq.Location = new System.Drawing.Point(274, 345);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.ReadOnly = true;
            this.txtSalLiq.Size = new System.Drawing.Size(265, 48);
            this.txtSalLiq.TabIndex = 30;
            // 
            // lblMsg
            // 
            this.lblMsg.AutoSize = true;
            this.lblMsg.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsg.Location = new System.Drawing.Point(654, 135);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(50, 18);
            this.lblMsg.TabIndex = 31;
            this.lblMsg.Text = "label1";
            this.lblMsg.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(933, 484);
            this.Controls.Add(this.lblMsg);
            this.Controls.Add(this.txtSalLiq);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnVerif);
            this.Controls.Add(this.gBoxSexo);
            this.Controls.Add(this.gBoxCasado);
            this.Controls.Add(this.cBoxDep);
            this.Controls.Add(this.txtDescIr);
            this.Controls.Add(this.txtDescInss);
            this.Controls.Add(this.lblDescInss);
            this.Controls.Add(this.lblDescIr);
            this.Controls.Add(this.txtSalFam);
            this.Controls.Add(this.txtAliqInss);
            this.Controls.Add(this.txtAliqIR);
            this.Controls.Add(this.lblSalFam);
            this.Controls.Add(this.SalLiq);
            this.Controls.Add(this.lblAliqIR);
            this.Controls.Add(this.lblAliqInss);
            this.Controls.Add(this.txtSalBruto);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblDep);
            this.Controls.Add(this.lblFunc);
            this.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "Form1";
            this.TransparencyKey = System.Drawing.Color.White;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gBoxCasado.ResumeLayout(false);
            this.gBoxCasado.PerformLayout();
            this.gBoxSexo.ResumeLayout(false);
            this.gBoxSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFunc;
        private System.Windows.Forms.Label lblDep;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalBruto;
        private System.Windows.Forms.Label lblAliqInss;
        private System.Windows.Forms.Label lblAliqIR;
        private System.Windows.Forms.Label SalLiq;
        private System.Windows.Forms.Label lblSalFam;
        private System.Windows.Forms.TextBox txtAliqIR;
        private System.Windows.Forms.TextBox txtAliqInss;
        private System.Windows.Forms.TextBox txtSalFam;
        private System.Windows.Forms.Label lblDescIr;
        private System.Windows.Forms.Label lblDescInss;
        private System.Windows.Forms.TextBox txtDescInss;
        private System.Windows.Forms.TextBox txtDescIr;
        private System.Windows.Forms.ComboBox cBoxDep;
        private System.Windows.Forms.GroupBox gBoxCasado;
        private System.Windows.Forms.CheckBox cboxCasado;
        private System.Windows.Forms.GroupBox gBoxSexo;
        private System.Windows.Forms.Button btnVerif;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.TextBox txtSalLiq;
        private System.Windows.Forms.RadioButton rbtnMasc;
        private System.Windows.Forms.RadioButton rbtnFem;
        private System.Windows.Forms.Label lblMsg;
    }
}

